/**
 * Entity 'Book' class.
 * Columns - Id, title, isbn, genre
 */
package com.ims.galIMS.category;

import javax.persistence.*;

// Annotate POJO as entity to represent a database entity/object.
@Entity()
// Specify primary table for entity
@Table(name = "category")

public class Category {
    // Specify id as primary key
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /*
     * @Column annotation
     * nullable = specify whether column can be empty/null
     * unique = specify if column content must be unique
     * length = specify column's amount of characters
     */

    @Column(nullable = false, unique = true, length = 20)
    private String category_name;

    @Column(length = 100, nullable = false)
    private String date;

    @Column(length = 40, nullable = false)
    private String time;

    @Column(length = 40, nullable = false)
    private int total_prod;

    /*
     * Column Id
     */
    // Getter for id
    public Integer getId() {
        return id;
    }

    // Setter for id
    public void setId(Integer id) {
        this.id = id;
    }

    /*
     * Column category_name
     */
    // Getter for category_name
    public String getCategory_name() {
        return category_name;
    }

    // Setter for category_name
    public void setCategory_name(String category_name) {
        this.category_name = category_name;
    }

    /*
     * Column name
     */
    // Getter for date
    public String getDate() {
        return date;
    }
    // Setter for date
    public void setDate(String date) {
        this.date = date;
    }

    /*
     * Column time
     */
    // Getter for time
    public String getTime() {
        return time;
    }
    // Setter for time
    public void setTime(String time) {
        this.time = time;
    }

    public Integer getTotal_prod() {
        return total_prod;
    }
    // Setter for total_prod
    public void setTotal_prod(Integer total_prod) {
        this.total_prod = total_prod;
    }
}
