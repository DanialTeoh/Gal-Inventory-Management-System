/**
 * Service class & business logics for 'category'
 */
package com.ims.galIMS.category;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

// Annotate as Service class
@Service
public class CategoryService {

    // Specify amount of search results to show per page
    public static final int SEARCH_RESULT_PER_PAGE = 10;

    // Inject instance of CategoryRepository as repo
    @Autowired
    private CategoryRepository repo;

    // Define pagination to be used in controllers
    public Page<Category> search(String keyword, int pageNum) {
        // Interface for pagination, use PageRequest
        Pageable pageable = PageRequest.of(pageNum - 1, SEARCH_RESULT_PER_PAGE);
        return repo.search(keyword, pageable);
    }

    // Define list of product to be used in controllers
    public List<Category> listAll() {
        // Return all entries as List, use findAll() from CrudRepository
        return (List<Category>) repo.findAll();
    }

    // Define product saving to be used in controllers
    public void save(Category category) {
        // Save category
        repo.save(category);
    }

    // Define getting category by id to be used in controller
    // Throws CategoryNotFoundException if category is not found...
    // so we can do something about it later
    public Category get(Integer id) throws CategoryNotFoundException {
        // Declare container object and attempt to retrieve entity Category by id
        Optional<Category> result = repo.findById(id);
        // Category found
        if (result.isPresent()) {
            // Get the category
            return result.get();
        }
        // Category not found, throw CategoryNotFoundException
        throw new CategoryNotFoundException();
    }

    // Define deleting category by id to be used in controller
    // Like previously, we throw CategoryNotFoundException if category is not found
    public void delete(Integer id) throws CategoryNotFoundException {
        // Use countById, as declared in CategoryRepository class
        // We find out if a category exists for that id
        Long count = repo.countById(id);
        // Category does not exist
        if (count == null || count == 0) {
            // Throw CategoryNotFoundException
            throw new CategoryNotFoundException();
        }
        // Exception not thrown, category must exist...
        // delete it by its id using deleteById by CrudRepository
        repo.deleteById(id);
    }
}
