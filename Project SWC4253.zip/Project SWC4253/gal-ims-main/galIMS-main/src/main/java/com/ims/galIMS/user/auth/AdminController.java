/**
 * Controller class for Admin
 */
package com.ims.galIMS.user.auth;

import com.ims.galIMS.category.Category;
import com.ims.galIMS.category.CategoryNotFoundException;
import com.ims.galIMS.category.CategoryService;
import com.ims.galIMS.product.Product;
import com.ims.galIMS.product.ProductNotFoundException;
import com.ims.galIMS.product.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private ProductService productService;

    @Autowired
    private CategoryService categoryService;

    @GetMapping("/product")
    public String adminProduct(Model model) {
        List<Product> listProducts = productService.listAll();
        model.addAttribute("listProduct", listProducts);
        model.addAttribute("totalItems", listProducts.size());
        return "admin/product";
    }

    @PostMapping("/product/save")
    public String saveProduct(Product product) {
        productService.save(product);
        return "redirect:/admin/product?add";
    }

    @GetMapping("/product/add")
    public String adminAddProduct(Model model) {
        return "admin/addProduct";
    }

    @GetMapping("/product/edit/{id}")
    public String adminEditProduct(@PathVariable("id") Integer id, Model model) {
        try {
            Product product = productService.get(id);
            model.addAttribute("product", product);
            model.addAttribute("pageTitle", "Edit product (ID: " + id + ")");
            return "admin/edit_Product";
        } catch (ProductNotFoundException e) {
            return "redirect:/admin/product?notExist";
        }
    }

    @GetMapping("/product/delete/{id}")
    public String adminDeleteProduct(@PathVariable("id") Integer id, Model model) {
        try {
            productService.delete(id);
            return "redirect:/admin/product?deleted=" + id;
        } catch (ProductNotFoundException e) {
            return "redirect:/admin/product?notExist";
        }
    }

    @GetMapping("/product/search")
    public String search(@RequestParam("keyword") String keyword, Model model) {
        return searchByPage(keyword, model, 1);
    }

    @GetMapping("/product/search/page/{pageNum}")
    public String searchByPage(@RequestParam("keyword") String keyword, Model model,
                               @PathVariable(name = "pageNum") int pageNum) {
        Page<Product> result = productService.search(keyword, pageNum);
        List<Product> listResult = result.getContent();
        model.addAttribute("totalPages", result.getTotalPages());
        model.addAttribute("totalItems", result.getTotalElements());
        model.addAttribute("currentPage", pageNum);
        long startCount = (pageNum - 1) * ProductService.SEARCH_RESULT_PER_PAGE + 1;
        model.addAttribute("startCount", startCount);
        long endCount = startCount + ProductService.SEARCH_RESULT_PER_PAGE - 1;
        if (endCount > result.getTotalElements()) {
            endCount = result.getTotalElements();
        }
        model.addAttribute("endCount", endCount);
        model.addAttribute("listResult", listResult);
        model.addAttribute("keyword", keyword);
        return "admin/searchProduct";
    }

    @GetMapping("/category")
    public String adminCategory(Model model) {
        List<Category> listResultSub = categoryService.listAll();
        model.addAttribute("listCategory", listResultSub);
        model.addAttribute("totalItems", listResultSub.size());
        return "admin/category";
    }

    @PostMapping("/category/save")
    public String saveCategory(Category category) {
        categoryService.save(category);
        return "redirect:/admin/category?add";
    }

    @GetMapping("/category/add")
    public String adminAddCategory(Model model) {
        return "admin/addCategory";
    }

    // Map HTTP GET requests for '/admin/category/edit/{id}'
    @GetMapping("/category/edit/{id}")
    public String adminEditCategory(@PathVariable("id") Integer id, Model model) {
        try {
            // Get the category by its id
            Category category = categoryService.get(id);
            // Store the category entity in attribute to be used in Thymeleaf
            model.addAttribute("category", category);
            model.addAttribute("pageTitle", "Edit category (ID: " + id + ")");

            // Return templates/admin/editCategory.html
            return "admin/editCategory";
        } catch (CategoryNotFoundException e) {
            // Handle the CategoryNotFoundException here
            // You can redirect or show an error message
            return "redirect:/admin/category?notExist";
        }
    }

    // Map HTTP GET requests for '/admin/category/delete/{id}'
    @GetMapping("/category/delete/{id}")
    public String adminDeleteCategory(@PathVariable("id") Integer id, Model model) {
        try {
            // Delete the category by its id
            categoryService.delete(id);

            // Success, redirect to list of categories with a param for message
            return "redirect:/admin/category?deleted=" + id;
        } catch (CategoryNotFoundException e) {
            // Handle the CategoryNotFoundException here
            // You can redirect or show an error message
            return "redirect:/admin/category?notExist";
        }
    }


    @GetMapping("/category/categorySearch")
    public String searchCategory(@RequestParam("keyword") String keyword, Model model) {
        return searchByPage2(keyword, model, 1);
    }

    @GetMapping("/category/categorySearch/page/{pageNum}")
    public String searchByPage2(@RequestParam("keyword") String keyword, Model model,
                                @PathVariable(name = "pageNum") int pageNum) {
        Page<Category> result = categoryService.search(keyword, pageNum);
        List<Category> listResult = result.getContent();
        model.addAttribute("totalPages", result.getTotalPages());
        model.addAttribute("totalItems", result.getTotalElements());
        model.addAttribute("currentPage", pageNum);
        long startCount = (pageNum - 1) * ProductService.SEARCH_RESULT_PER_PAGE + 1;
        model.addAttribute("startCount", startCount);
        long endCount = startCount + ProductService.SEARCH_RESULT_PER_PAGE - 1;
        if (endCount > result.getTotalElements()) {
            endCount = result.getTotalElements();
        }
        model.addAttribute("endCount", endCount);
        model.addAttribute("listResult", listResult);
        model.addAttribute("keyword", keyword);
        return "admin/categorySearch";
    }
}
