/**
 * Entity 'Book' class.
 * Columns - Id, title, isbn, genre
 */
package com.ims.galIMS.product;

import javax.persistence.*;

// Annotate POJO as entity to represent a database entity/object.
@Entity()
// Specify primary table for entity
@Table(name = "product")

public class Product {
    // Specify id as primary key
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /*
    * @Column annotation
    * nullable = specify whether column can be empty/null
    * unique = specify if column content must be unique
    * length = specify column's amount of characters
    */

    @Column(length = 100, nullable = false)
    private String name;


    /*
    * Column Id
     */
    // Getter for id
    public Integer getId() {
        return id;
    }

    // Setter for id
    public void setId(Integer id) {
        this.id = id;
    }


    /*
     * Column name
     */
    // Getter for name
    public String getName() {
        return name;
    }
    // Setter for name
    public void setName(String name) {
        this.name = name;
    }


}
