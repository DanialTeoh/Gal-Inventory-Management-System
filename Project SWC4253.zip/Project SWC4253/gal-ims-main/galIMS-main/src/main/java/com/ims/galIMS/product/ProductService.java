package com.ims.galIMS.product;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {

    public static final int SEARCH_RESULT_PER_PAGE = 10;

    @Autowired
    private ProductRepository repo;

    public Page<Product> search(String keyword, int pageNum) {
        Pageable pageable = PageRequest.of(pageNum - 1, SEARCH_RESULT_PER_PAGE);
        return repo.search(keyword, pageable);
    }

    public List<Product> listAll() {
        return (List<Product>) repo.findAll();
    }

    public void save(Product product) {
        repo.save(product);
    }

    public Product get(Integer id) throws ProductNotFoundException {
        Optional<Product> result = repo.findById(id);
        if (result.isPresent()) {
            return result.get();
        }
        throw new ProductNotFoundException("Product not found with id: " + id);
    }

    public void delete(Integer id) throws ProductNotFoundException {
        if (repo.existsById(id)) {
            repo.deleteById(id);
        } else {
            throw new ProductNotFoundException("Product not found with id: " + id);
        }
    }

    public void update(Integer id, Product updatedProduct) throws ProductNotFoundException {
        if (repo.existsById(id)) {
            updatedProduct.setId(id);
            repo.save(updatedProduct);
        } else {
            throw new ProductNotFoundException("Product not found with id: " + id);
        }
    }
}
