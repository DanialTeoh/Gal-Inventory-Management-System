package com.ims.galIMS.category;

public class CategoryNotFoundException extends Throwable {
}
